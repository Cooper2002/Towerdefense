#include "enemy.h"

Enemy::Enemy(QWidget *parent) : QWidget(parent)
{

}
