#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPoint>
#include<QImage>
#include <QTimer>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setFixedSize(1024,512);
    setWindowTitle("塔防");

    QImage title;
    //title =all.copy(32,416,32,64);
   setWindowIcon(QIcon("D:/title.png"));
   QTimer *timer=new QTimer(this);
   timer->start(500);
   connect(timer,&QTimer::timeout,[=](){
      posx=posx-32;
      update();
   });

}
void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QImage pix;
    pix.load(":/TileB.png");
    //painter.drawImage(0,0,pix);
    QImage road;
    road=pix.copy(96,64,96,32);
    QImage tree;
    tree=pix.copy(192,128,64,64);
    QImage home;home=pix.copy(352,352,64,64);
    painter.drawImage(0,224,home);

for(int i=0;i<=20;i++)
{
    painter.drawImage(96*i+64,224,road);
    painter.drawImage(96*i+64,256,road);
    painter.drawImage(64*i,160,tree);
    painter.drawImage(64*i,288,tree);
}
QImage title;
title =pix.copy(32,416,32,64);
painter.drawImage(posx,224,title);


}
MainWindow::~MainWindow()
{
    delete ui;
}

