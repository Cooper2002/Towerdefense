#ifndef ENEMY_H
#define ENEMY_H

#include <QMainWindow>
#include <QWidget>

class Enemy : public QWidget
{
    Q_OBJECT
public:
    explicit Enemy(QWidget *parent = nullptr);

signals:

};

#endif // ENEMY_H
